import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildQuickStats(),
            const SizedBox(height: 20),
            _buildSectionTitle('Platform Overview', Icons.analytics),
            const SizedBox(height: 12),
            _buildPlatformCards(),
            const SizedBox(height: 20),
            _buildSectionTitle('Advisor Management', Icons.verified_user),
            const SizedBox(height: 12),
            _buildAdvisorCards(),
            const SizedBox(height: 20),
            _buildSectionTitle('Recent Users', Icons.people),
            const SizedBox(height: 12),
            _buildUserCards(),
            const SizedBox(height: 20),
            _buildSectionTitle('Subscription Overview', Icons.subscriptions),
            const SizedBox(height: 12),
            _buildSubscriptionCard(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.2),
            ),
            child: const Icon(Icons.admin_panel_settings,
                color: Colors.white, size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Admin Dashboard',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
                const SizedBox(height: 4),
                Text('The Scalable CFO',
                    style: TextStyle(
                        fontSize: 13, color: Colors.white.withOpacity(0.7))),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8)),
            child: const Text('Live',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStats() {
    return Row(
      children: [
        _statCard('Total Users', '342', AppTheme.primary, Icons.people),
        const SizedBox(width: 10),
        _statCard('Advisors', '28', AppTheme.info, Icons.verified_user),
        const SizedBox(width: 10),
        _statCard('Companies', '156', AppTheme.success, Icons.business),
      ],
    );
  }

  Widget _statCard(String label, String value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 2))
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(height: 8),
            Text(value,
                style: TextStyle(
                    fontSize: 18, fontWeight: FontWeight.bold, color: color)),
            const SizedBox(height: 2),
            Text(label,
                style: const TextStyle(
                    fontSize: 11, color: AppTheme.textSecondary),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 18, color: AppTheme.primary),
        const SizedBox(width: 8),
        Text(title,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: AppTheme.textPrimary)),
      ],
    );
  }

  Widget _buildPlatformCards() {
    final List<Map<String, dynamic>> items = [
      {
        'title': 'Active Users',
        'value': '245',
        'change': '+12%',
        'icon': Icons.people,
        'color': AppTheme.primary
      },
      {
        'title': 'Monthly Revenue',
        'value': '₹12.5L',
        'change': '+8%',
        'icon': Icons.attach_money,
        'color': AppTheme.success
      },
      {
        'title': 'Platform Uptime',
        'value': '99.9%',
        'change': 'Stable',
        'icon': Icons.check_circle,
        'color': AppTheme.accentGold
      },
      {
        'title': 'Avg Session',
        'value': '18m',
        'change': '+2m',
        'icon': Icons.timer,
        'color': AppTheme.info
      },
    ];
    return Column(
      children: items
          .map((item) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2))
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: (item['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12)),
                      child: Icon(item['icon'] as IconData,
                          color: item['color'] as Color, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item['title']!,
                              style: const TextStyle(
                                  fontSize: 14, color: AppTheme.textSecondary)),
                          const SizedBox(height: 2),
                          Row(
                            children: [
                              Text(item['value']!,
                                  style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: AppTheme.textPrimary)),
                              const SizedBox(width: 8),
                              Text(item['change']!,
                                  style: TextStyle(
                                      fontSize: 12, color: AppTheme.success)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios,
                        size: 14, color: AppTheme.textHint),
                  ],
                ),
              ))
          .toList(),
    );
  }

  Widget _buildAdvisorCards() {
    final List<Map<String, dynamic>> advisors = [
      {
        'name': 'Sarah Chen',
        'status': 'Verified',
        'clients': '8',
        'color': AppTheme.success
      },
      {
        'name': 'Michael Brown',
        'status': 'Pending',
        'clients': '3',
        'color': AppTheme.warning
      },
      {
        'name': 'Emily Davis',
        'status': 'Verified',
        'clients': '12',
        'color': AppTheme.success
      },
      {
        'name': 'James Wilson',
        'status': 'Suspended',
        'clients': '0',
        'color': AppTheme.error
      },
    ];
    return Column(
      children: advisors
          .map((a) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2))
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: AppTheme.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12)),
                      child: const Icon(Icons.person,
                          color: AppTheme.primary, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(a['name']!,
                              style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.textPrimary)),
                          const SizedBox(height: 2),
                          Text('${a['clients']} clients',
                              style: const TextStyle(
                                  fontSize: 12, color: AppTheme.textSecondary)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                          color: (a['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8)),
                      child: Text(a['status']!,
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: a['color'] as Color)),
                    ),
                  ],
                ),
              ))
          .toList(),
    );
  }

  Widget _buildUserCards() {
    final List<Map<String, dynamic>> users = [
      {
        'name': 'TechFlow Inc.',
        'plan': 'Premium',
        'color': AppTheme.accentGold
      },
      {
        'name': 'GreenEnergy Co.',
        'plan': 'Standard',
        'color': AppTheme.primary
      },
      {'name': 'EduLearn', 'plan': 'Premium', 'color': AppTheme.accentGold},
      {'name': 'HealthPlus', 'plan': 'Basic', 'color': AppTheme.textSecondary},
    ];
    return Column(
      children: users
          .map((u) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2))
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: AppTheme.success.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12)),
                      child: const Icon(Icons.business,
                          color: AppTheme.success, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(u['name']!,
                              style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.textPrimary)),
                          const SizedBox(height: 2),
                          Text('${u['plan']} plan',
                              style: const TextStyle(
                                  fontSize: 12, color: AppTheme.textSecondary)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                          color: (u['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8)),
                      child: Text(u['plan']!,
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: u['color'] as Color)),
                    ),
                  ],
                ),
              ))
          .toList(),
    );
  }

  Widget _buildSubscriptionCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                    color: AppTheme.accentGold.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.subscriptions,
                    color: AppTheme.accentGold, size: 22),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Plans Distribution',
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary)),
                    SizedBox(height: 2),
                    Text('Active subscriptions by tier',
                        style: TextStyle(
                            fontSize: 12, color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _planStat('Premium', '42', AppTheme.accentGold),
              const SizedBox(width: 12),
              _planStat('Standard', '89', AppTheme.primary),
              const SizedBox(width: 12),
              _planStat('Basic', '211', AppTheme.textSecondary),
            ],
          ),
        ],
      ),
    );
  }

  Widget _planStat(String label, String value, Color color) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold, color: color)),
          const SizedBox(height: 2),
          Text(label,
              style:
                  const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
        ],
      ),
    );
  }
}
