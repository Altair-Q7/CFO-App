import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';

class AdvisorDashboardScreen extends StatelessWidget {
  const AdvisorDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildQuickStats(),
            const SizedBox(height: 20),
            _buildSectionTitle('Client Portfolio', Icons.business_center),
            const SizedBox(height: 12),
            _buildClientCards(),
            const SizedBox(height: 20),
            _buildSectionTitle('Upcoming Sessions', Icons.calendar_today),
            const SizedBox(height: 12),
            _buildSessionCards(),
            const SizedBox(height: 20),
            _buildSectionTitle('Revenue Tracking', Icons.attach_money),
            const SizedBox(height: 12),
            _buildRevenueCard(),
            const SizedBox(height: 20),
            _buildSectionTitle('Recent Activity', Icons.history),
            const SizedBox(height: 12),
            _buildActivityCards(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.2),
            ),
            child: const Icon(Icons.person, color: Colors.white, size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Advisor Dashboard',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
                const SizedBox(height: 4),
                Text('Sarah Chen · CFO Advisory',
                    style: TextStyle(
                        fontSize: 13, color: Colors.white.withOpacity(0.7))),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8)),
            child: const Text('Live',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStats() {
    return Row(
      children: [
        _statCard('Active Clients', '12', AppTheme.primary, Icons.people),
        const SizedBox(width: 10),
        _statCard('Sessions', '8', AppTheme.success, Icons.event),
        const SizedBox(width: 10),
        _statCard('Revenue', '₹4.2L', AppTheme.accentGold, Icons.attach_money),
      ],
    );
  }

  Widget _statCard(String label, String value, Color color, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 2))
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(height: 8),
            Text(value,
                style: TextStyle(
                    fontSize: 18, fontWeight: FontWeight.bold, color: color)),
            const SizedBox(height: 2),
            Text(label,
                style: const TextStyle(
                    fontSize: 11, color: AppTheme.textSecondary),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 18, color: AppTheme.primary),
        const SizedBox(width: 8),
        Text(title,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: AppTheme.textPrimary)),
      ],
    );
  }

  Widget _buildClientCards() {
    final List<Map<String, dynamic>> clients = [
      {
        'name': 'TechFlow Inc.',
        'status': 'Active',
        'color': AppTheme.success,
        'revenue': '₹1.2L'
      },
      {
        'name': 'GreenEnergy Co.',
        'status': 'Active',
        'color': AppTheme.success,
        'revenue': '₹95K'
      },
      {
        'name': 'HealthPlus',
        'status': 'Onboarding',
        'color': AppTheme.warning,
        'revenue': '₹80K'
      },
      {
        'name': 'EduLearn',
        'status': 'Active',
        'color': AppTheme.success,
        'revenue': '₹1.1L'
      },
    ];
    return Column(
      children: clients
          .map((client) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2))
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: AppTheme.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12)),
                      child: const Icon(Icons.business,
                          color: AppTheme.primary, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(client['name']!,
                              style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.textPrimary)),
                          const SizedBox(height: 2),
                          Text('Revenue: ${client['revenue']}',
                              style: const TextStyle(
                                  fontSize: 12, color: AppTheme.textSecondary)),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                          color: (client['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8)),
                      child: Text(client['status']!,
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: client['color'] as Color)),
                    ),
                  ],
                ),
              ))
          .toList(),
    );
  }

  Widget _buildSessionCards() {
    final List<Map<String, dynamic>> sessions = [
      {
        'client': 'TechFlow Inc.',
        'time': 'Today, 3:00 PM',
        'type': 'Quarterly Review',
        'color': AppTheme.primary
      },
      {
        'client': 'GreenEnergy Co.',
        'time': 'Tomorrow, 10:00 AM',
        'type': 'Budget Planning',
        'color': AppTheme.info
      },
      {
        'client': 'HealthPlus',
        'time': 'Jun 16, 2:00 PM',
        'type': 'Onboarding Call',
        'color': AppTheme.warning
      },
    ];
    return Column(
      children: sessions
          .map((s) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2))
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: (s['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12)),
                      child: Icon(Icons.event,
                          color: s['color'] as Color, size: 22),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(s['client']!,
                              style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.textPrimary)),
                          const SizedBox(height: 2),
                          Text('${s['type']} · ${s['time']}',
                              style: const TextStyle(
                                  fontSize: 12, color: AppTheme.textSecondary)),
                        ],
                      ),
                    ),
                    Icon(Icons.arrow_forward_ios,
                        size: 14, color: AppTheme.textHint),
                  ],
                ),
              ))
          .toList(),
    );
  }

  Widget _buildRevenueCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                    color: AppTheme.accentGold.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.trending_up,
                    color: AppTheme.accentGold, size: 22),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Monthly Revenue',
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary)),
                    SizedBox(height: 2),
                    Text('This month vs last month',
                        style: TextStyle(
                            fontSize: 12, color: AppTheme.textSecondary)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _revenueStat('This Month', '₹4.2L', AppTheme.success),
              const SizedBox(width: 16),
              _revenueStat('Last Month', '₹3.8L', AppTheme.textSecondary),
              const SizedBox(width: 16),
              _revenueStat('Growth', '+10.5%', AppTheme.success),
            ],
          ),
        ],
      ),
    );
  }

  Widget _revenueStat(String label, String value, Color color) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.bold, color: color)),
          const SizedBox(height: 2),
          Text(label,
              style:
                  const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
        ],
      ),
    );
  }

  Widget _buildActivityCards() {
    final List<Map<String, dynamic>> activities = [
      {
        'title': 'New client onboarding completed',
        'time': '2 hours ago',
        'icon': Icons.person_add,
        'color': AppTheme.success
      },
      {
        'title': 'Quarterly report delivered to TechFlow',
        'time': '5 hours ago',
        'icon': Icons.receipt,
        'color': AppTheme.info
      },
      {
        'title': 'Budget review session scheduled',
        'time': '1 day ago',
        'icon': Icons.event,
        'color': AppTheme.warning
      },
    ];
    return Column(
      children: activities
          .map((a) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2))
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                          color: (a['color'] as Color).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10)),
                      child: Icon(a['icon'] as IconData,
                          color: a['color'] as Color, size: 20),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(a['title']!,
                              style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                  color: AppTheme.textPrimary)),
                          const SizedBox(height: 2),
                          Text(a['time']!,
                              style: const TextStyle(
                                  fontSize: 12, color: AppTheme.textSecondary)),
                        ],
                      ),
                    ),
                  ],
                ),
              ))
          .toList(),
    );
  }
}
