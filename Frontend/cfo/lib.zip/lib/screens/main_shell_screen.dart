import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/constants/app_constants.dart';
import '../providers/providers.dart';
import 'dashboard/founder_dashboard_screen.dart';
import 'dashboard/advisor_dashboard_screen.dart';
import 'dashboard/admin_dashboard_screen.dart';
import 'forecasting/forecast_screen.dart';
import 'ai_assistant/chat_screen.dart';
import 'reports/reports_screen.dart';

class MainShellScreen extends ConsumerStatefulWidget {
  const MainShellScreen({super.key});

  @override
  ConsumerState<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends ConsumerState<MainShellScreen> {
  int _currentIndex = 0;

  List<Widget> _getScreens() {
    final role = ref.watch(authProvider).role;
    switch (role) {
      case 'advisor':
        return [
          const AdvisorDashboardScreen(),
          const ForecastScreen(),
          const AiChatScreen(),
          const ReportsScreen(),
          _buildMoreMenu(),
        ];
      case 'admin':
        return [
          const AdminDashboardScreen(),
          const ForecastScreen(),
          const AiChatScreen(),
          const ReportsScreen(),
          _buildMoreMenu(),
        ];
      default:
        return [
          const FounderDashboardScreen(),
          const ForecastScreen(),
          const AiChatScreen(),
          const ReportsScreen(),
          _buildMoreMenu(),
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final screens = _getScreens();

    return Scaffold(
      body: screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 20,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _navItem(Icons.dashboard_rounded, 'Dashboard', 0),
                _navItem(Icons.trending_up_rounded, 'Forecast', 1),
                _navItem(Icons.smart_toy_rounded, 'AI', 2),
                _navItem(Icons.receipt_long_rounded, 'Reports', 3),
                _navItem(Icons.menu_rounded, 'More', 4),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItem(IconData icon, String label, int index) {
    final isSelected = _currentIndex == index;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => _currentIndex = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primary.withOpacity(0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 22,
              color: isSelected ? AppTheme.primary : AppTheme.textHint,
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                color: isSelected ? AppTheme.primary : AppTheme.textHint,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMoreMenu() {
    return Scaffold(
      appBar: AppBar(title: const Text('Menu')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _menuCard(
            Icons.store_rounded,
            'Marketplace',
            'Find and book CFO advisors',
            AppTheme.info,
            () => Navigator.pushNamed(context, '/marketplace'),
          ),
          _menuCard(
            Icons.volunteer_activism_rounded,
            'Fundraising',
            'Readiness score & data room',
            AppTheme.success,
            () => Navigator.pushNamed(context, '/fundraising'),
          ),
          _menuCard(
            Icons.notifications_rounded,
            'Notifications',
            'Alerts and updates',
            AppTheme.warning,
            () => Navigator.pushNamed(context, '/notifications'),
          ),
          _menuCard(
            Icons.person_rounded,
            'Profile',
            'Account & company info',
            AppTheme.primary,
            () => Navigator.pushNamed(context, '/profile'),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.backgroundLight,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded,
                    size: 18, color: AppTheme.textHint),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Demo Mode · Mock Data · No server required',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppTheme.textHint,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _menuCard(IconData icon, String title, String subtitle, Color color,
      VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: color, size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  size: 14,
                  color: AppTheme.textHint,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
